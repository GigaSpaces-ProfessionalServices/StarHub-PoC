#!/bin/bash

set -e

sudo initctl stop nodecellar
