cloudify-vtm-plugin
========================

* Master Branch [![Build Status](https://travis-ci.org/cloudify-cosmo/cloudify-plugin-template.svg?branch=master)](https://travis-ci.org/cloudify-cosmo/cloudify-plugin-template)

Cloudify plugin project template.

## Usage

See [Plugin Authoring Guide](http://getcloudify.org/guide/3.2/plugins-authoring.html)

## Tests

To run the example plugin tests, the included `dev-requirements.txt` should be installed.

```
pip install -r dev-requirements.txt
```
