#!/bin/bash

sudo apt-get update
sudo apt-get install -y nginx
sudo service nginx start
