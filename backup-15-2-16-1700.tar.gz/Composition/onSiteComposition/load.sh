cfy blueprints upload -b ServiceChain -p servicetemplate.yaml
cfy blueprints upload -b loadbalancer -p loadbalancer.yaml
cfy blueprints upload -b firewall -p firewall.yaml

