#!/bin/bash

ctx logger info "Starting Logstash Service..."
sudo systemctl start logstash