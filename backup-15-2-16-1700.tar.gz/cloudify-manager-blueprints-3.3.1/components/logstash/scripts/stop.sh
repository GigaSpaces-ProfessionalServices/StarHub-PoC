#!/bin/bash

ctx logger info "Stopping Logstash..."
sudo systemctl stop logstash
