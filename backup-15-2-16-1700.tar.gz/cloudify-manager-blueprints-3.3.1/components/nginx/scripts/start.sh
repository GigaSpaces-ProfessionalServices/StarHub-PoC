#!/bin/bash -e

ctx logger info "Starting Nginx Service..."
sudo systemctl start nginx.service