# Cloudify Manager Blueprints

This repository contains blueprints for bootstrapping Cloudify

## Usage

See [Bootstrapping Cloudify](http://getcloudify.org/guide/installation-bootstrapping.html)
